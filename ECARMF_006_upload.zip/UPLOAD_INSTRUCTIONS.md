# Upload Instructions

Upload the contents of this package to the repository root.

## Commit Message

```text
feat(ecarmf-006): establish Knowledge Graph Standard engineering baseline
```

## Package Contents

```text
docs/standards/ECARMF-006-Knowledge-Graph-Standard/
```
